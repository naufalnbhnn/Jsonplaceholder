package com.adambennett.api.service.models

data class Post(
    val title: String,
    val body: String,
    val userId: Int,
    val id: Int
)
