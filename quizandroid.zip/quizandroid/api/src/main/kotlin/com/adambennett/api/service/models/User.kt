package com.adambennett.api.service.models

data class User(
    val userName: String,
    val id: Int
)
