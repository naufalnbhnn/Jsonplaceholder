[![CircleCI](https://circleci.com/gh/ditn/JsonPlaceholderApp.svg?style=svg)](https://circleci.com/gh/ditn/JsonPlaceholderApp)

# JsonPlaceholderApp

An example app written with the http://jsonplaceholder.typicode.com/ API. Utilises Kotlin, RxJava and MVI.

I chose to focus more on the architecture of this project because I wanted to attempt to utilise ViewModels + MVI + Koin in a nice way, and because architecture is generally more interesting to me.